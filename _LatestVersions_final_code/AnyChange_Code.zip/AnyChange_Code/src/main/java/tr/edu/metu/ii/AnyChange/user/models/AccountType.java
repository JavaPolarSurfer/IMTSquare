package tr.edu.metu.ii.AnyChange.user.models;

public enum AccountType {
    STANDART,
    PREMIUM
}
