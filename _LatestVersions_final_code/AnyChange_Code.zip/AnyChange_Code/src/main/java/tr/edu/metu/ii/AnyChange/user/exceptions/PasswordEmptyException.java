package tr.edu.metu.ii.AnyChange.user.exceptions;

public class PasswordEmptyException extends Exception {
    public PasswordEmptyException(String message) {
        super(message);
    }
}
