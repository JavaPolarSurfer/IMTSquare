package tr.edu.metu.ii.AnyChange.user.exceptions;

public class LastNameEmptyException extends Exception{
    public LastNameEmptyException(String message) {
        super(message);
    }
}
