package tr.edu.metu.ii.AnyChange.user.exceptions;

public class InvalidExpirationDateException extends Exception {
    public InvalidExpirationDateException(String message) {
        super(message);
    }
}
