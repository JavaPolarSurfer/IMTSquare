package tr.edu.metu.ii.AnyChange.product.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductPricesDTO {
    private String priceSourceName;
    private String price;
    private String history;
}
