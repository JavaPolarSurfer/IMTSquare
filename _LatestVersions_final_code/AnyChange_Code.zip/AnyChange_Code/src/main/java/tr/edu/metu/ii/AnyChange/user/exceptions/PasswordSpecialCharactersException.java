package tr.edu.metu.ii.AnyChange.user.exceptions;

public class PasswordSpecialCharactersException extends Exception {
    public PasswordSpecialCharactersException(String message) {
        super(message);
    }
}
