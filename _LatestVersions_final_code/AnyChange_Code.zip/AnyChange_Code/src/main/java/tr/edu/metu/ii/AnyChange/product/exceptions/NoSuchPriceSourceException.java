package tr.edu.metu.ii.AnyChange.product.exceptions;

public class NoSuchPriceSourceException extends Exception {
    public NoSuchPriceSourceException(String message) {
        super(message);
    }
}
