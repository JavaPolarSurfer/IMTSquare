package tr.edu.metu.ii.AnyChange.user.exceptions;

public class InvalidConfirmationTokenException extends Exception {
    public InvalidConfirmationTokenException(String message) {
        super(message);
    }
}
