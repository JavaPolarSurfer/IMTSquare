package tr.edu.metu.ii.AnyChange.user.models;

public enum UserRole {
    USER,
    ADMIN
}
