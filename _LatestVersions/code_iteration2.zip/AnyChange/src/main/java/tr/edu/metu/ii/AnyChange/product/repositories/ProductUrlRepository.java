package tr.edu.metu.ii.AnyChange.product.repositories;

import org.springframework.data.repository.CrudRepository;
import tr.edu.metu.ii.AnyChange.product.models.ProductUrl;

public interface ProductUrlRepository extends CrudRepository<ProductUrl, Long> {
}
