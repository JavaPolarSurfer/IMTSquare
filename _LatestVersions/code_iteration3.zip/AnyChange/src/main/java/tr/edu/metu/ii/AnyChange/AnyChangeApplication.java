package tr.edu.metu.ii.AnyChange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnyChangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnyChangeApplication.class, args);
	}

}
