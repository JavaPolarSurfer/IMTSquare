package tr.edu.metu.ii.AnyChange.user.exceptions;

public class PasswordCantBeSameException extends Exception {
    public PasswordCantBeSameException(String message) {
        super(message);
    }
}
