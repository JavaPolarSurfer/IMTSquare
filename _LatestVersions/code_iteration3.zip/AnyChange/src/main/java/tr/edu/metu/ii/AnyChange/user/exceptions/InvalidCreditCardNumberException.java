package tr.edu.metu.ii.AnyChange.user.exceptions;

public class InvalidCreditCardNumberException extends Exception {
    public InvalidCreditCardNumberException(String message) {
        super(message);
    }
}
