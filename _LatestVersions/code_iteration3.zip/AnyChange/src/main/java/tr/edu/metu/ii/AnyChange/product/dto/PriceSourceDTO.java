package tr.edu.metu.ii.AnyChange.product.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PriceSourceDTO {
    private long id;
    private String name;
}
