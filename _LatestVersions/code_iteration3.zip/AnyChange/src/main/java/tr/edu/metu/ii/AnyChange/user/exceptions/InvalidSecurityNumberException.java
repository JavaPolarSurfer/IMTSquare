package tr.edu.metu.ii.AnyChange.user.exceptions;

public class InvalidSecurityNumberException extends Exception {
    public InvalidSecurityNumberException(String message) {
        super(message);
    }
}
