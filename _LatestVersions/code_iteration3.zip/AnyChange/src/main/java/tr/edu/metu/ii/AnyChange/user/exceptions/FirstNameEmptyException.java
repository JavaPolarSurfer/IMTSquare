package tr.edu.metu.ii.AnyChange.user.exceptions;

public class FirstNameEmptyException extends Exception {
    public FirstNameEmptyException(String message) {
        super(message);
    }
}
