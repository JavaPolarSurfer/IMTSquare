package tr.edu.metu.ii.AnyChange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnyChangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
